import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://hiru404.web.id',
  integrations: [sitemap()],
});
