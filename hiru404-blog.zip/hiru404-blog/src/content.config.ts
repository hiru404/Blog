import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const blog = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/blog' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    date: z.coerce.date(),
    kategori: z.enum(['tema', 'tutorial', 'forum']).default('tutorial'),
    tags: z.array(z.string()).default([]),
  }),
});

export const collections = { blog };
