# Hiru404 Blog (Astro + Cloudflare Pages)

## Jalankan lokal
    npm install
    npm run dev

## Tambah artikel
Buat file `.md` di `src/content/blog/` dengan frontmatter:
title, description, date, kategori (tema | tutorial | forum), tags.

## Deploy ke Cloudflare Pages
1. Push folder ini ke GitHub.
2. Cloudflare Dashboard > Workers & Pages > Create > Pages > Connect to Git.
3. Build command: `npm run build`, output directory: `dist`. Node 20+.
4. Custom domains > tambahkan `hiru404.web.id`.

## Forum
Buka https://giscus.app, aktifkan GitHub Discussions di repo, lalu isi nilai
`data-repo`, `data-repo-id`, `data-category-id` di `src/pages/forum.astro`.
